import boto3
from botocore.exceptions import ClientError

def stop_ec2_instances(instance_ids):
    """
    Função para desligar instâncias EC2 pelo ID.

    :param instance_ids: Lista de IDs das instâncias EC2 a serem desligadas
    """
    ec2_client = boto3.client('ec2')

    try:
        response = ec2_client.stop_instances(InstanceIds=instance_ids)
        print(f"Instâncias {instance_ids} estão sendo desligadas.")
        return response
    
    except ClientError as e:
        print(f"Erro ao desligar as instâncias: {e}")
        return None

def lambda_handler(event, context):
    """
    Função de entrada do Lambda.
    Recebe uma lista de IDs de instâncias EC2 no evento e chama a função para desligá-las.
    """
    instance_ids = event.get('instance_ids', [])
    
    if instance_ids:
        return stop_ec2_instances(instance_ids)
    else:
        return {"error": "Nenhum ID de instância fornecido."}
